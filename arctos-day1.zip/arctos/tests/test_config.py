"""Configuration validation tests (unittest: no extra dependency)."""

import unittest
from pathlib import Path

from arctos.config import ConfigurationError, load_settings


class SettingsTests(unittest.TestCase):
    def test_defaults(self) -> None:
        settings = load_settings({})
        self.assertEqual(settings.log_level, "INFO")
        self.assertEqual(settings.workspace, Path.cwd().resolve())

    def test_environment_overrides(self) -> None:
        settings = load_settings(
            {"ARCTOS_LOG_LEVEL": "debug", "ARCTOS_WORKSPACE": "."}
        )
        self.assertEqual(settings.log_level, "DEBUG")
        self.assertEqual(settings.workspace, Path.cwd().resolve())

    def test_invalid_log_level(self) -> None:
        with self.assertRaisesRegex(ConfigurationError, "ARCTOS_LOG_LEVEL"):
            load_settings({"ARCTOS_LOG_LEVEL": "TRACE"})


if __name__ == "__main__":
    unittest.main()
