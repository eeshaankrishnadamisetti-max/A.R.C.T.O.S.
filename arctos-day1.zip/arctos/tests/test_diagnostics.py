"""Tests for environment checks and their failure modes."""

import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from arctos.diagnostics import run_diagnostics


class DiagnosticsTests(unittest.TestCase):
    def test_valid_workspace_passes(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(
                os.environ,
                {"ARCTOS_LOG_LEVEL": "INFO", "ARCTOS_WORKSPACE": directory},
            ):
                checks, settings = run_diagnostics()
        self.assertIsNotNone(settings)
        self.assertTrue(any(c.name == "Workspace" and c.status == "PASS" for c in checks))

    def test_missing_workspace_fails(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            missing = Path(directory) / "does-not-exist"
            with patch.dict(os.environ, {"ARCTOS_WORKSPACE": str(missing)}):
                checks, _ = run_diagnostics()
        self.assertTrue(any(c.name == "Workspace" and c.status == "FAIL" for c in checks))

    def test_unknown_os_warns(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {"ARCTOS_WORKSPACE": directory}):
                with patch("arctos.diagnostics.platform.system", return_value="UnknownOS"):
                    checks, _ = run_diagnostics()
        self.assertTrue(
            any(c.name == "Operating system" and c.status == "WARN" for c in checks)
        )


if __name__ == "__main__":
    unittest.main()
