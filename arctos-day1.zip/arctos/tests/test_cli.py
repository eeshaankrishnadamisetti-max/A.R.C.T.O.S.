"""CLI behavior and error exit-code tests."""

import os
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from unittest.mock import patch

from arctos.interfaces.cli import main


class CliTests(unittest.TestCase):
    def test_version(self) -> None:
        output = StringIO()
        with redirect_stdout(output):
            with self.assertRaises(SystemExit) as caught:
                main(["--version"])
        self.assertEqual(caught.exception.code, 0)
        self.assertIn("arctos 0.1.0", output.getvalue())

    def test_doctor_succeeds(self) -> None:
        output = StringIO()
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(
                os.environ,
                {"ARCTOS_LOG_LEVEL": "INFO", "ARCTOS_WORKSPACE": directory},
            ):
                with redirect_stdout(output):
                    exit_code = main(["doctor"])
        self.assertEqual(exit_code, 0)
        self.assertIn("ARCTOS Doctor", output.getvalue())
        self.assertIn("[PASS] Workspace", output.getvalue())

    def test_bad_configuration_returns_failure(self) -> None:
        output = StringIO()
        with patch.dict(os.environ, {"ARCTOS_LOG_LEVEL": "NOT_A_LEVEL"}):
            with redirect_stdout(output):
                exit_code = main(["doctor"])
        self.assertEqual(exit_code, 1)
        self.assertIn("[FAIL] Configuration", output.getvalue())


if __name__ == "__main__":
    unittest.main()
