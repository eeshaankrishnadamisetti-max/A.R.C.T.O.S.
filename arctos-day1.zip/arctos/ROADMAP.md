# ARCTOS — 30-day engineering sprint

**Target:** By Day 30, demonstrate a coding agent plus the first real, controlled connection to physical Atlas. This is a milestone plan, not a guarantee that all future ARCTOS features will exist then.

| Day | Deliverable |
| --- | --- |
| 1 | Package, CLI, `doctor`, configuration, logging, tests, docs, Git. |
| 2 | Define agent task contracts, permission model, and test fixtures. |
| 3 | Add workspace discovery and safe path validation. |
| 4 | Implement read-only file listing and reading tools. |
| 5 | Add file reading tests and large-file guards. |
| 6 | Define pluggable provider interface, mock provider tests. |
| 7 | Integrate one hosted model API using separately supplied credentials. |
| 8 | Implement one-shot prompt -> proposed action (no auto-execute). |
| 9 | Add unified diff generation and preview. |
| 10 | Add approved atomic single-file edits and rollback tests. |
| 11 | Support multi-file edit plans and human approval. |
| 12 | Add constrained subprocess execution with timeouts. |
| 13 | Command allowlist/denylist and risk classification. |
| 14 | Run project tests and capture bounded output. |
| 15 | Build observe -> plan -> approve -> act -> verify loop. |
| 16 | Add bounded retry and failure-stop logic. |
| 17 | Improve CLI conversations and streaming if supported. |
| 18 | Introduce task logs with secret redaction. |
| 19 | Add per-project context files with explicit loading. |
| 20 | Run coding-agent end-to-end fixture tests. |
| 21 | Harden workspace isolation and adversarial tests. |
| 22 | Define Atlas message schema, commands, telemetry, and authentication. |
| 23 | Implement Atlas adapter with mock transport. |
| 24 | Build a local Atlas simulator for connection tests. |
| 25 | Select and prepare physical transport and microcontroller firmware. |
| 26 | Test heartbeat, reconnect, and offline behavior. |
| 27 | Connect to physical Atlas for read-only telemetry. |
| 28 | Add one safe, explicitly approved low-risk device command. |
| 29 | End-to-end regression and recovery testing. |
| 30 | Demo coding agent plus authenticated physical Atlas connection; document limitations. |

## Scope controls

Only create capabilities once prerequisites and tests exist. If physical hardware is not ready, demonstrate a simulator and document physical integration as incomplete rather than claiming success. Prioritize a reliable coding agent, safety gates, and a genuine Atlas link over extra interfaces or ambitious autonomy.
