"""Read-only environment and configuration health checks."""

import platform
import sys
from dataclasses import dataclass
from typing import Literal

from arctos.config import ConfigurationError, Settings, load_settings

Status = Literal["PASS", "WARN", "FAIL"]
SUPPORTED_SYSTEMS = frozenset({"Windows", "Linux", "Darwin"})


@dataclass(frozen=True, slots=True)
class Check:
    status: Status
    name: str
    detail: str


def run_diagnostics() -> tuple[list[Check], Settings | None]:
    """Return checks and valid settings, if available. Never alter the system."""
    checks: list[Check] = []

    python_version = ".".join(str(part) for part in sys.version_info[:3])
    supported_python = sys.version_info >= (3, 11)
    checks.append(
        Check(
            "PASS" if supported_python else "FAIL",
            "Python",
            f"{python_version} (requires 3.11+)",
        )
    )

    system = platform.system()
    checks.append(
        Check(
            "PASS" if system in SUPPORTED_SYSTEMS else "WARN",
            "Operating system",
            f"{system} {platform.release()}".strip(),
        )
    )

    try:
        settings = load_settings()
    except (ConfigurationError, OSError) as exc:
        checks.append(Check("FAIL", "Configuration", str(exc)))
        checks.append(Check("WARN", "Workspace", "Not checked: configuration invalid"))
        return checks, None

    checks.append(
        Check("PASS", "Configuration", f"ARCTOS_LOG_LEVEL={settings.log_level}")
    )
    checks.append(
        Check(
            "PASS" if settings.workspace.is_dir() else "FAIL",
            "Workspace",
            str(settings.workspace)
            if settings.workspace.is_dir()
            else f"Missing or not a directory: {settings.workspace}",
        )
    )
    return checks, settings
