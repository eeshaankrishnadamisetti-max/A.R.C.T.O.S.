"""Read and validate ARCTOS configuration from environment variables."""

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

VALID_LOG_LEVELS = frozenset({"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"})


class ConfigurationError(ValueError):
    """Raised for invalid user-provided configuration."""


@dataclass(frozen=True, slots=True)
class Settings:
    log_level: str
    workspace: Path


def load_settings(env: Mapping[str, str] | None = None) -> Settings:
    """Load settings; defaults require no .env file or third-party package."""
    source = os.environ if env is None else env
    log_level = source.get("ARCTOS_LOG_LEVEL", "INFO").strip().upper()
    if log_level not in VALID_LOG_LEVELS:
        allowed = ", ".join(sorted(VALID_LOG_LEVELS))
        raise ConfigurationError(
            f"ARCTOS_LOG_LEVEL must be one of: {allowed}"
        )

    raw_workspace = source.get("ARCTOS_WORKSPACE", "").strip()
    workspace = Path(raw_workspace).expanduser() if raw_workspace else Path.cwd()
    return Settings(log_level=log_level, workspace=workspace.resolve())
