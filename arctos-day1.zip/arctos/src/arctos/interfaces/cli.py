"""Dependency-free ARCTOS command-line interface."""

import argparse
import sys
from importlib.metadata import PackageNotFoundError, version
from typing import Sequence

from arctos.diagnostics import run_diagnostics
from arctos.logging_setup import configure_logging


def installed_version() -> str:
    """Use installed package metadata as the single version source."""
    try:
        return version("arctos")
    except PackageNotFoundError:
        return "not installed"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="arctos",
        description="ARCTOS personal AI system (Day 1 foundation)",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"arctos {installed_version()}",
    )
    commands = parser.add_subparsers(dest="command")
    commands.add_parser("doctor", help="Check Python, OS, and configuration")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the CLI; return a process status for the installed console script."""
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_help()
        return 0

    try:
        checks, settings = run_diagnostics()
        logger = configure_logging(settings.log_level if settings else "INFO")
        logger.debug("Completed %d environment checks", len(checks))

        print("ARCTOS Doctor")
        for check in checks:
            print(f"[{check.status}] {check.name}: {check.detail}")

        passed = sum(check.status == "PASS" for check in checks)
        warnings = sum(check.status == "WARN" for check in checks)
        failed = sum(check.status == "FAIL" for check in checks)
        print(f"Summary: {passed} passed, {warnings} warnings, {failed} failed")
        return 1 if failed else 0
    except Exception:
        configure_logging("INFO").exception("Unexpected command failure")
        print("ARCTOS failed unexpectedly; see the error log above.", file=sys.stderr)
        return 1
