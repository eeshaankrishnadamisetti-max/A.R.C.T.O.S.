"""Allow execution with ``python -m arctos``."""

from arctos.interfaces.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
