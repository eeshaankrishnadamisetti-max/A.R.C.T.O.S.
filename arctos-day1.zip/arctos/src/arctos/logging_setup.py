"""Centralized ARCTOS logging configuration."""

import logging
import sys


def configure_logging(level: str = "INFO") -> logging.Logger:
    """Configure one stderr handler without duplicating it on repeat calls."""
    logger = logging.getLogger("arctos")
    logger.setLevel(getattr(logging, level))
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(
            logging.Formatter("%(levelname)s [%(name)s] %(message)s")
        )
        logger.addHandler(handler)
    logger.propagate = False
    return logger
