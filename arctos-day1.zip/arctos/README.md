# ARCTOS

**Adaptive Recursive Cognitive Task Orchestration System**

Day 1 is a small, installable Python CLI. It has no LLM integration, filesystem editing, command-execution agent, persistence, or hardware control yet.

## Requirements

- Python 3.11 or newer; Windows PowerShell is the primary development shell.
- Git (required for the version-control steps, not for CLI execution).
- Internet access may be needed once to install the Python packaging build tools.

## Install (PowerShell)

From the project root (the folder containing `pyproject.toml`):

```powershell
py -3 --version
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -e .
```

Verify that the Python version is 3.11 or newer. If `py` is unavailable, use an installed Python 3.11+ executable in its place.

## Run

```powershell
.\.venv\Scripts\arctos.exe --version
.\.venv\Scripts\arctos.exe doctor
.\.venv\Scripts\arctos.exe --help
.\.venv\Scripts\python.exe -m arctos doctor
```

The console command is also available as `arctos` when the virtual environment's `Scripts` directory is on `PATH` (for example, after activation). Running its executable by explicit path avoids PowerShell activation-policy issues.

## Configuration

Settings come **only from process environment variables**, with safe defaults. `.env` files are **not automatically loaded**.

| Variable | Default | Purpose |
| --- | --- | --- |
| `ARCTOS_LOG_LEVEL` | `INFO` | One of `DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL` |
| `ARCTOS_WORKSPACE` | Current working directory | Directory checked by `doctor` |

Example for the current PowerShell window:

```powershell
$env:ARCTOS_LOG_LEVEL = "DEBUG"
$env:ARCTOS_WORKSPACE = (Get-Location).Path
.\.venv\Scripts\arctos.exe doctor
Remove-Item Env:ARCTOS_LOG_LEVEL
Remove-Item Env:ARCTOS_WORKSPACE
```

`doctor` checks that Python is 3.11+, identifies the OS, validates the log level, and checks that the workspace exists as a directory. It does **not** create or modify the workspace. Statuses: `PASS` / `WARN` / `FAIL`. A failed check returns process exit code `1`; warnings alone do not fail the command.

## Tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

No separate test framework is required. Before a release, run the test suite on Windows in addition to any tests run on other operating systems.

## Structure and next steps

Read [ARCHITECTURE.md](ARCHITECTURE.md) for module ownership, [ROADMAP.md](ROADMAP.md) for the 30-day plan, and [AGENTS.md](AGENTS.md) before AI-assisted changes. The project is cloud-first by design; **a ChatGPT Plus subscription does not include API credits**, and no API key is necessary for Day 1.
