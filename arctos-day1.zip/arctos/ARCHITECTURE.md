# ARCTOS architecture — Day 1

## Scope

The Day 1 deliverable is a Python package and terminal entry point, not an autonomous agent. It has zero runtime third-party dependencies and does not contact any external service.

## Implemented components

| File/package | Responsibility |
| --- | --- |
| `arctos.interfaces.cli` | Parse terminal arguments, render diagnostics, select exit codes. |
| `arctos.config` | Interpret and validate environment variables into immutable settings. |
| `arctos.diagnostics` | Perform read-only Python, OS, configuration, and workspace checks. |
| `arctos.logging_setup` | Configure namespaced stderr logging once. |
| `arctos.__main__` | Support `python -m arctos`. |

Dependency direction: `interfaces.cli` -> `diagnostics` and `logging_setup`; `diagnostics` -> `config`. Configuration never imports the interface. Standard-library `argparse`, `logging`, and `unittest` keep the foundation lightweight.

## Future boundaries — NOT implemented today

- `core/`: orchestrate tasks, state transitions, and bounded agent loops.
- `providers/`: abstract model APIs; no provider should be hardcoded into core.
- `tools/`: inspect/edit files and run commands only within explicit permissions.
- `memory/`: retain project context and durable state, with consent and isolation.
- `interfaces/`: CLI today; GUI, voice, and remote interfaces later.
- `atlas/`: validated messaging and device status for physical Atlas.

Create these packages only when the first real implementation is needed. Interfaces should depend on core service APIs, rather than placing agent logic inside CLI handlers. Hardware drivers and cloud-model providers must not depend on each other.

## Security and design constraints

1. Cloud inference is optional and replaceable; ARCTOS is not tied to a ChatGPT subscription.
2. No implicit execution of shell commands, code mutations, or device actions.
3. Limit future filesystem tools to an approved workspace; reject traversal and symlink escapes.
4. Keep model-generated plans separate from actions. Require approval for risky operations.
5. Read credentials at runtime from environment or a secure credential store; never log or commit them.
6. Atlas integration must authenticate its peer and enforce device-side safety limits.

## Release criteria for this stage

Editable installation succeeds, version and doctor commands work, unit tests pass, and ignored sensitive files stay out of Git. A later milestone adds interfaces, not Day 1 placeholder packages.
