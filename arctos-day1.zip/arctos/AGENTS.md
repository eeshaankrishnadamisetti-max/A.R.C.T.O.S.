# ARCTOS — agent-assisted development rules

This file guides ChatGPT, Cursor, and future coding agents when proposing code changes.

## Workflow

1. Read `README.md`, `ARCHITECTURE.md`, and this file before major changes.
2. State the task scope and acceptance criteria; keep edits small and reviewable.
3. Provide complete file contents or an explicit diff with every modified path.
4. Use Python 3.11+ syntax and type hints; keep dependencies minimal.
5. Prefer standard-library modules and `src/arctos/` package boundaries.
6. Include tests for new behavior and failure modes; never claim tests passed without executing them.
7. Run `python -m unittest discover -s tests -v` and `arctos doctor` after relevant changes.
8. Inspect `git diff --check`, `git diff`, and staged files before committing.
9. Keep `pyproject.toml` as the canonical package-version source; CLI reads installed metadata.

## Non-negotiable safety rules

- Do not include secrets in code, chat logs, fixtures, commits, or command output.
- Never commit `.env`, virtual environments, credentials, private keys, or generated logs.
- Do not execute commands proposed by a model without scoped authorization.
- Future file tools must use a user-approved workspace and reject path escapes.
- Destructive commands, network operations, installations, and system changes require explicit approval.
- Apply bounded timeouts, output limits, and retry limits to future tools.
- Keep plan generation and side-effecting tool execution separate.
- Atlas must default to safe state on disconnect and enforce hardware-level limits; cloud commands alone are not sufficient safeguards.
- Day 1 must contain no LLM calls, autonomous tool execution, persistent memory, or Atlas communications.

## Windows developer commands

Run from the project root in PowerShell:

```powershell
.\.venv\Scripts\python.exe -m pip install -e .
.\.venv\Scripts\arctos.exe --version
.\.venv\Scripts\arctos.exe doctor
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

On failure, capture the command, exit code, and traceback, then fix the smallest root cause. Mark untested platform behavior as unverified. Never silently suppress errors to make checks appear green.
